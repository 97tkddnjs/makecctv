from django.apps import AppConfig


class CctvConfig(AppConfig):
    name = 'cctv'
